[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/XiFIQTfY)


# toelichting memory game 

## ons doel:
We hebben eigenlijk een kleine memory game gemaakt waarbij het de bedoeling is dat de spelers hun geheugen gaan trainen en verbeteren door hen te vragen om paren van kaarten of afbeeldingen te vinden die bij elkaar horen. Door het spel te spelen, worden spelers aangemoedigd om hun kortetermijngeheugen en hun visuele geheugen te gebruiken en te oefenen. 

## De bedoeling van het spel is: 
om alle paren te vinden door kaarten om te draaien en ze te matchen voordat de tijd om is. Memory games kunnen niet alleen leuk zijn om te spelen, maar ook nuttig zijn als educatief hulpmiddel om kinderen te helpen nieuwe informatie te leren en te onthouden, zoals letters, cijfers, woorden, afbeeldingen en concepten.